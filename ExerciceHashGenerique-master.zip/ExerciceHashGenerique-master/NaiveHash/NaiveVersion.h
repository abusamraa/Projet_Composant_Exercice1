#pragma once
#ifndef NAIVEVERSION_H
#define NAIVEVERSION_H

#define NAIVE_VERSION 1,0,0,0
#define NAIVE_VERSION_STR "1,0,0,0"

#endif
